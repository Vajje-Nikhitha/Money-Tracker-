import { createActions } from 'redux-actions';

export const {
  saveExportFile
} = createActions(
  'SAVE_EXPORT_FILE'
);
