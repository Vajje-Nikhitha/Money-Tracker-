import { createAction } from 'redux-actions';

export const toggleSidebar = createAction('TOGGLE_SIDEBAR');
