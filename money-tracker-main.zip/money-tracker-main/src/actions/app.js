import { createAction } from 'redux-actions';

export const bootstrap = createAction('BOOTSTRAP');
