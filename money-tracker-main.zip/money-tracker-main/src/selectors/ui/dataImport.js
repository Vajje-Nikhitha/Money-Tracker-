export const getImportFile = state => state.ui.dataImport.file;
