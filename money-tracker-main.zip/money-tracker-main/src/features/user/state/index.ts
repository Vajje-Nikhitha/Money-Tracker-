import { UserUiSaga } from './ui';

export const UserSaga = [...UserUiSaga];
